<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Search Profile</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style_css1.css">
</head>

<body>

<div class="container d-flex justify-content-center align-items-center min-vh-100">

    <div class="form-card">

        <div class="header text-center">
            <h1>Search Profile</h1>
            <p>Search by Student ID or Name</p>
        </div>

        <form action="searchProfile" method="get">

            <div class="mb-4">
                <label class="form-label">Enter Student ID or Name</label>
                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Example: 2025141905 or Alia"
                    required
                >
            </div>

            <button type="submit" class="btn btn-primary w-100 py-3">
                Search
            </button>

        </form>

        <a href="viewProfiles" class="btn btn-secondary w-100 py-3 mt-3">
            Back to Profiles
        </a>

    </div>

</div>

</body>
</html>