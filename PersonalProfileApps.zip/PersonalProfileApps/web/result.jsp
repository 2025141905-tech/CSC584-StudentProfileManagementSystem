<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>

<head>

    <title>Student Profile</title>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


    <link rel="stylesheet" href="style_css1.css">

</head>

<body>

<div class="container d-flex justify-content-center align-items-center min-vh-100">

    <div class="profile-card">

        <div class="header text-center">

            <h1>Student Profile</h1>

            <p>
                Your submitted information
            </p>

        </div>

        <div class="info-box">

            <p>
                <span>👤 Full Name:</span>
                <%= request.getAttribute("name") %>
            </p>

            <p>
                <span>🆔 Student ID:</span>
                <%= request.getAttribute("studentId") %>
            </p>

            <p>
                <span>🎓 Program:</span>
                <%= request.getAttribute("program") %>
            </p>

            <p>
                <span>📧 Email:</span>
                <%= request.getAttribute("email") %>
            </p>

            <p>
                <span>✨ Hobbies:</span>
                <%= request.getAttribute("hobbies") %>
            </p>

            <p>
                <span>💬 Introduction:</span>
                <%= request.getAttribute("intro") %>
            </p>

        </div>

        <a href="index.html"
           class="btn btn-primary w-100 py-3 back-btn">

            Back to Form

        </a>

    </div>

</div>

</body>
</html>