<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="model.ProfileBean"%>

<!DOCTYPE html>
<html>
<head>
    <title>Saved Profile</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style_css1.css">
</head>

<body>

<div class="container d-flex justify-content-center align-items-center min-vh-100">

    <div class="profile-card">

        <div class="header text-center">
            <h1>Student Profile</h1>
            <p>Your profile has been saved successfully.</p>
        </div>

        <%
            ProfileBean profile = (ProfileBean) request.getAttribute("profile");
        %>

        <div class="info-box">

            <p><span>Full Name:</span> <%= profile.getName() %></p>
            <p><span>Student ID:</span> <%= profile.getStudentID() %></p>
            <p><span>Programme:</span> <%= profile.getProgramme() %></p>
            <p><span>Email:</span> <%= profile.getEmail() %></p>
            <p><span>Hobbies:</span> <%= profile.getHobbies() %></p>
            <p><span>Introduction:</span> <%= profile.getIntroduction() %></p>

        </div>

        <a href="viewProfiles" class="btn btn-primary w-100 py-3 mb-2">
            View All Profiles
        </a>

        <a href="index.html" class="btn btn-secondary w-100 py-3">
            Back to Form
        </a>

    </div>

</div>

</body>
</html>