<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<%@page import="model.ProfileBean"%>

<!DOCTYPE html>
<html>
<head>
    <title>Filter Result</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style_css1.css">
</head>

<body>

<div class="container py-5">

    <div class="profile-card mx-auto" style="max-width: 1000px;">

        <div class="header text-center">
            <h1>Filter Result</h1>
            <p>Filtered profile records</p>
        </div>

        <%
            ArrayList<ProfileBean> results =
                (ArrayList<ProfileBean>) request.getAttribute("filterResults");
        %>

        <div class="table-responsive">

            <table class="table table-bordered table-hover text-center align-middle">

                <thead class="table-primary">
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Programme</th>
                        <th>Email</th>
                        <th>Hobbies</th>
                        <th>Introduction</th>
                    </tr>
                </thead>

                <tbody>

                <%
                    if (results != null && !results.isEmpty()) {
                        for (ProfileBean p : results) {
                %>

                    <tr>
                        <td><%= p.getStudentID() %></td>
                        <td><%= p.getName() %></td>
                        <td><%= p.getProgramme() %></td>
                        <td><%= p.getEmail() %></td>
                        <td><%= p.getHobbies() %></td>
                        <td><%= p.getIntroduction() %></td>
                    </tr>

                <%
                        }
                    } else {
                %>

                    <tr>
                        <td colspan="6">No matching records found.</td>
                    </tr>

                <%
                    }
                %>

                </tbody>

            </table>

        </div>

        <a href="filter.jsp" class="btn btn-primary w-100 py-3 mb-2">
            Filter Again
        </a>

        <a href="viewProfiles" class="btn btn-secondary w-100 py-3">
            View All Profiles
        </a>

    </div>

</div>

</body>
</html>