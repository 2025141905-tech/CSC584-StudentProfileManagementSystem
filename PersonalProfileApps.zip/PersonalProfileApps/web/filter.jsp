<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>

    <title>Filter Profiles</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="style_css1.css">

</head>

<body>

<div class="container d-flex justify-content-center align-items-center min-vh-100">

    <div class="form-card">

        <div class="header text-center">

            <h1>Filter Profiles</h1>

            <p>
                Filter records by programme and hobbies
            </p>

        </div>

        <form action="filterProfiles" method="get">

            <div class="mb-3">

                <label class="form-label">
                    Programme
                </label>

                <input
                    type="text"
                    name="programme"
                    class="form-control"
                    placeholder="Example: CDCS266"
                    required
                >

            </div>

            <div class="mb-4">

                <label class="form-label">
                    Hobbies
                </label>

                <input
                    type="text"
                    name="hobbies"
                    class="form-control"
                    placeholder="Example: swimming"
                    required
                >

            </div>

            <button
                type="submit"
                class="btn btn-primary w-100 py-3">

                Filter

            </button>

        </form>

        <a
            href="viewProfiles"
            class="btn btn-secondary w-100 py-3 mt-3">

            Back to Profiles

        </a>

    </div>

</div>

</body>
</html>