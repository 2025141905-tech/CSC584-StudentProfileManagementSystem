<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<%@page import="model.ProfileBean"%>

<!DOCTYPE html>
<html>
<head>
    <title>View Profiles</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style_css1.css">
</head>

<body>

<div class="container py-5">

    <div class="profile-card mx-auto" style="max-width: 1000px;">

        <div class="header text-center">
            <h1>All Student Profiles</h1>
            <p>List of profiles stored in the database</p>
        </div>

        <div class="mb-3 text-center">
            <a href="index.html" class="btn btn-primary">Add New Profile</a>
            <a href="search.jsp" class="btn btn-secondary">Search Profile</a>
            <a href="filter.jsp" class="btn btn-info">Filter Profiles</a>
        </div>

        <%
            ArrayList<ProfileBean> profiles =
                (ArrayList<ProfileBean>) request.getAttribute("profiles");
        %>

        <div class="table-responsive">
            <table class="table table-bordered table-hover text-center align-middle">

                <thead class="table-primary">
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Programme</th>
                        <th>Email</th>
                        <th>Hobbies</th>
                        <th>Introduction</th>
                    </tr>
                </thead>

                <tbody>

                <%
                    if (profiles != null && !profiles.isEmpty()) {
                        for (ProfileBean p : profiles) {
                %>

                    <tr>
                        <td><%= p.getStudentID() %></td>
                        <td><%= p.getName() %></td>
                        <td><%= p.getProgramme() %></td>
                        <td><%= p.getEmail() %></td>
                        <td><%= p.getHobbies() %></td>
                        <td><%= p.getIntroduction() %></td>
                    </tr>

                <%
                        }
                    } else {
                %>

                    <tr>
                        <td colspan="6">No profile records found.</td>
                    </tr>

                <%
                    }
                %>

                </tbody>

            </table>
        </div>

    </div>

</div>

</body>
</html>