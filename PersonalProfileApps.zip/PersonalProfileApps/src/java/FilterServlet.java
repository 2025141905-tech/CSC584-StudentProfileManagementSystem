import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ProfileBean;

@WebServlet("/filterProfiles")
public class FilterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String programme = request.getParameter("programme");
        String hobbies = request.getParameter("hobbies");

        if (programme == null) {
            programme = "";
        }

        if (hobbies == null) {
            hobbies = "";
        }

        ArrayList<ProfileBean> filterResults = new ArrayList<ProfileBean>();

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            Connection conn = DriverManager.getConnection(
                    "jdbc:derby://localhost:1527/StudentProfilesDB",
                    "app",
                    "app"
            );

            String sql =
                    "SELECT * FROM Profile "
                    + "WHERE LOWER(programme) LIKE ? "
                    + "AND LOWER(hobbies) LIKE ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, "%" + programme.toLowerCase() + "%");
            ps.setString(2, "%" + hobbies.toLowerCase() + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ProfileBean profile = new ProfileBean();

                profile.setStudentID(rs.getString("studentID"));
                profile.setName(rs.getString("name"));
                profile.setProgramme(rs.getString("programme"));
                profile.setEmail(rs.getString("email"));
                profile.setHobbies(rs.getString("hobbies"));
                profile.setIntroduction(rs.getString("introduction"));

                filterResults.add(profile);
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("filterResults", filterResults);

        RequestDispatcher rd =
                request.getRequestDispatcher("filterResult.jsp");

        rd.forward(request, response);
    }
}